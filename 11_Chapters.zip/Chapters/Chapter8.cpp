#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/objdetect.hpp>
#include <iostream>

using namespace cv;
using namespace std;


/////////////////  Resize and crop  //////////////////////

int main() {
    string path = "images/test.jpg";
    Mat img = imread(path);


    imshow("Image", img);
    waitKey(0);

}
/*g++ test1.cpp -o test1 `pkg-config --cflags --libs opencv4`*/


