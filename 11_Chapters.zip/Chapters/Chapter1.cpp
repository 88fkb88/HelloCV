  #include <opencv2/imgcodecs.hpp>
  #include <opencv2/highgui.hpp>
  #include <opencv2/imgproc.hpp>
  #include <iostream>

  using namespace cv;
  using namespace std;


  /////////////////  Images  //////////////////////

  // int main() {

  //     string path = "images/mj_1.png";
  //     Mat img = imread(path);
  //     cout<<"1145655514"<<endl;
  //     if(img.empty()) {
  //       cout << "错误：无法加载图像 " << path << endl;
  //       return -1;
  //     }

  //     imshow("Image", img);
  //     waitKey(0);

  // }
  /*g++ test1.cpp -o test1 `pkg-config --cflags --libs opencv4`*/


  /////////////// Videos /////////
  // int main() {

  //     string path = "video/test_01.mp4";
  //     VideoCapture cap(path);
  //     Mat img ;
  //     cout<<114514<<endl;
  //     while(1){
  //       cap.read(img);
  //       imshow("Image",img);
  //       waitKey(20);
  //     }
      

  // }





  //////////////////////////////////     webcam //////////////////////////
  int main() {

      VideoCapture cap(0);
      Mat img ;

      while(1){
        cap.read(img);
        imshow("Image",img);
        waitKey(1);
      }
      

  }