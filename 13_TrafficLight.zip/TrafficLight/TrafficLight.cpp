#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <vector>
#include <string>

using namespace cv;
using namespace std;

//存储红绿灯位置信息
struct TrafficLightPosition {
    Rect redZone;
    Rect yellowZone;
    Rect greenZone;
    bool initialized;
    
    TrafficLightPosition():initialized(false) {}
};
TrafficLightPosition lightPosition;



//初始化红绿灯位置，主要为了判断黄灯 
void initializeLightPosition(const Rect& redLightRect, const Size& frameSize) {
    if (lightPosition.initialized) return;
    
    //已知红绿灯是垂直排列的
    int lightHeight = redLightRect.height;
    int lightWidth = redLightRect.width;
    int x = redLightRect.x;
    int y = redLightRect.y;
    
    // 计算三个灯的位置
    lightPosition.redZone = Rect(x, y, lightWidth, lightHeight);
    lightPosition.yellowZone = Rect(x, y + lightHeight, lightWidth, lightHeight);
    lightPosition.greenZone = Rect(x, y + 2 * lightHeight, lightWidth, lightHeight);
    lightPosition.initialized = true;
//    
//    cout << "红绿灯位置已初始化:" << endl;
//    cout << "红灯区域: " << lightPosition.redZone << endl;
//    cout << "黄灯区域: " << lightPosition.yellowZone << endl;
//    cout << "绿灯区域: " << lightPosition.greenZone << endl;
}

//计算区域的圆形度，用来排除未知原因造成的检测点偏移 
double calculateCircularity(const vector<Point>& contour) {
    double area = contourArea(contour);
    double perimeter = arcLength(contour, true);
    if (perimeter == 0) return 0;
    return (4 * CV_PI * area) / (perimeter * perimeter);
}


string detectTrafficLightColor(Mat& frame) {//进一步处理加强精度 
    Mat hsv;
    cvtColor(frame, hsv, COLOR_BGR2HSV);//转化为HSV 
    
    //分离HSV通道
    vector<Mat> hsvChannels;
    split(hsv, hsvChannels);
    Mat hue = hsvChannels[0];
    Mat saturation = hsvChannels[1];
    Mat value = hsvChannels[2];
    
	//红 
    Mat redMask1, redMask2, redMask;
    inRange(hsv, Scalar(0, 100, 150), Scalar(10, 255, 255), redMask1);
    inRange(hsv, Scalar(160, 100, 150), Scalar(180, 255, 255), redMask2);
    bitwise_or(redMask1, redMask2, redMask);
    
    //绿
    Mat greenMask;
    inRange(hsv, Scalar(40, 80, 120), Scalar(90, 255, 255), greenMask);
    
    //黄
    Mat yellowMask;
    inRange(hsv, Scalar(15, 80, 120), Scalar(35, 255, 255), yellowMask);
    
    //用来强化颜色区域检测，考虑到阴影等问题 
    Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(7, 7));
    morphologyEx(redMask, redMask, MORPH_CLOSE, kernel);
    morphologyEx(greenMask, greenMask, MORPH_CLOSE, kernel);
    morphologyEx(yellowMask, yellowMask, MORPH_CLOSE, kernel);
    
    //确定灯泡轮廓 
    vector<vector<Point>> redContours, greenContours;
    findContours(redMask, redContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    findContours(greenMask, greenContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    
    string detectedColor = "";
    Rect bestRect;//创建矩形 
    double maxScore = -1;
    
    //分析红色轮廓
    for (const auto& contour : redContours) {
        double area=contourArea(contour);
        if (area < 500) continue; //过滤小区域
        
        Rect rect = boundingRect(contour);
        double circularity = calculateCircularity(contour);
        
        //从这里往下都是在尽量排除黄灯干扰 
        bool inCorrectPosition = true;
        if (lightPosition.initialized) {
            Point center(rect.x + rect.width/2, rect.y + rect.height/2);
            inCorrectPosition = lightPosition.redZone.contains(center);
        }
        
        Mat roiYellow = yellowMask(rect);
        int yellowPixels = countNonZero(roiYellow);//统计区域中非零像素的数量 
        double yellowRatio = (double)yellowPixels / (rect.width * rect.height);
        
        // 计算得分，通过得分确定到底是红还是黄 
        double score = area * circularity;
        if (inCorrectPosition) score *= 1.5; //位置正确的区域得分更高
        
        if (yellowRatio > 0.3) score *= 0.1;
        
        if (score > maxScore && circularity > 0.4) {
            maxScore = score;
            detectedColor = "RED";
            bestRect = rect;
        }
    }
    
    //分析绿色轮廓，与红类似 
    for (const auto& contour : greenContours) {
        double area = contourArea(contour);
        if (area < 500) continue;
        
        Rect rect = boundingRect(contour);
        double circularity = calculateCircularity(contour);
        
        bool inCorrectPosition = true;
        if (lightPosition.initialized) {
            Point center(rect.x + rect.width/2, rect.y + rect.height/2);
            inCorrectPosition = lightPosition.greenZone.contains(center);
        }
        
        double score = area * circularity;
        if (inCorrectPosition) score *= 1.5;
        
        if (score > maxScore && circularity > 0.4) {
            maxScore = score;
            detectedColor = "GREEN";
            bestRect = rect;
        }
    }
    
    //判断是不是检测到了真正的红绿灯 
    if (!detectedColor.empty() && maxScore > 10000) { //设置最小得分
        rectangle(frame, bestRect, Scalar(255, 0, 255), 3);//画框 
        
        // 在左上角显示颜色信息
        putText(frame, detectedColor + " LIGHT", Point(20, 40), FONT_HERSHEY_SIMPLEX, 1.2, Scalar(255, 0, 255), 3);

        //如果是第一次检测到红灯，初始化位置
        if (detectedColor == "RED" && !lightPosition.initialized) {
            initializeLightPosition(bestRect, frame.size());
        }
    }
    
    return detectedColor;
}
int main() {
    string inputPath = "TrafficLight.mp4";
    string outputPath = "result.avi";//设置输入输出路径 
    
//    cout << "尝试打开输入视频: " << inputPath << endl;
    
    VideoCapture inputVideo(inputPath);//输入视频 
    if (!inputVideo.isOpened()) {//自报错检测 
//        cout << "错误: 无法打开输入视频" << endl;
        return -1;
    }
    
    int frameWidth = static_cast<int>(inputVideo.get(CAP_PROP_FRAME_WIDTH));
    int frameHeight = static_cast<int>(inputVideo.get(CAP_PROP_FRAME_HEIGHT));
    double fps = inputVideo.get(CAP_PROP_FPS);
    int totalFrames = static_cast<int>(inputVideo.get(CAP_PROP_FRAME_COUNT));//获取视频信息，用于后期输出视频  

    VideoWriter outputVideo;//设置好准备输出  
    outputVideo.open(outputPath, VideoWriter::fourcc('m', 'p', '4', 'v'), fps, Size(frameWidth, frameHeight));//输出视频 
    
    if (!outputVideo.isOpened()) {//自报错检测 
//        cout << "错误: 无法创建输出视频" << endl;
        return -1;
    }
    
//    cout << "开始处理视频..." << endl;
    
    Mat frame;
    int frameCount = 0;
    int detectedCount = 0;
    int redCount = 0;
    int greenCount = 0;
    
    while (true) {
        inputVideo.read(frame);//读入下一帧 
        if (frame.empty()) {//视频结束了跳出去 
            break;
        }
        
        string detectedColor = detectTrafficLightColor(frame);
        
        if (!detectedColor.empty()) {//找着东西了 
            detectedCount++;//总数++ 
            if (detectedColor == "RED") redCount++;
            else if (detectedColor == "GREEN") greenCount++;
//            cout << "帧 " << frameCount << ": 检测到 " << detectedColor << " 灯" << endl;
        }
        
        outputVideo.write(frame);//输出 
        frameCount++;
        
        // 显示进度
        if (frameCount % 10 == 0) {
            int progress = (totalFrames > 0) ? (frameCount * 100 / totalFrames) : 0;
//            cout << "已处理 " << frameCount << " 帧 (" << progress << "%)" << endl;
        }//进度条，用于确定报错位置 
    }
    return 0;
}