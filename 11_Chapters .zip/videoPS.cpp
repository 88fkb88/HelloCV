  #include <opencv2/imgcodecs.hpp>
  #include <opencv2/highgui.hpp>
  #include <opencv2/imgproc.hpp>
  #include <iostream>

  using namespace cv;
  using namespace std;


  /////////////////  Images  //////////////////////

  // int main() {

  //     string path = "images/mj_1.png";
  //     Mat img = imread(path);
  //     cout<<"1145655514"<<endl;
  //     if(img.empty()) {
  //       cout << "错误：无法加载图像 " << path << endl;
  //       return -1;
  //     }

  //     imshow("Image", img);
  //     waitKey(0);

  // }
  /*g++ test1.cpp -o test1 `pkg-config --cflags --libs opencv4`*/


  /////////////// Videos /////////
int main() {
    string path = "video/videoPS.mp4";
    VideoCapture cap(path);
    Mat img ;
    
    int time0=time(0);

    double fps = cap.get(CAP_PROP_FPS);
    Size frameSize(cap.get(CAP_PROP_FRAME_WIDTH), cap.get(CAP_PROP_FRAME_HEIGHT));

    VideoWriter writer("output.avi", VideoWriter::fourcc('M', 'J', 'P', 'G'), fps, frameSize);
    

    // cout<<time(0)<<endl;
    while(1){
      cap.read(img);
      if(img.empty()){
        break;
      }
      Mat imgPS=img.clone();
      int op=(int)time(0)-(int)time0;
      if(op>=0&&op<4){
        putText(imgPS,"Nothing!",Point(100,100),FONT_HERSHEY_COMPLEX,3,Scalar(0,69,255),2);
      }
      else if(op>=4&&op<=8){
        cvtColor (img,imgPS,COLOR_BGR2GRAY);
        putText(imgPS,"Gray!",Point(100,100),FONT_HERSHEY_COMPLEX,3,Scalar(0,69,255),2);
        cvtColor(imgPS, imgPS, COLOR_GRAY2BGR);
      }
      else if(op>8&&op<=12){
        GaussianBlur(imgPS,imgPS,Size(15,15),5,5);
        putText(imgPS,"Blur!",Point(100,100),FONT_HERSHEY_COMPLEX,3,Scalar(0,69,255),2);
      }
      else{
        Canny(img,imgPS,25,75);
        putText(imgPS,"Canny!",Point(100,100),FONT_HERSHEY_COMPLEX,3,Scalar(255,255,255),5);
        cvtColor(imgPS, imgPS, COLOR_GRAY2BGR);
      }
      writer.write(imgPS);

      imshow("VideoPS",imgPS);

      
      
      waitKey(20);
    }
    // cout<<time(0)<<endl;

    return 0;
}





  //////////////////////////////////     webcam //////////////////////////
//   int main() {

//       VideoCapture cap(0);
//       Mat img ;

//       while(1){
//         cap.read(img);
//         imshow("Image",img);
//         waitKey(1);
//       }
      

//   }